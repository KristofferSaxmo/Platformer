﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Template
{
    class Player : BaseClass
    {
        Vector2 velocity = Vector2.Zero;
        public Player(Texture2D texture, Vector2 position, Point size)
        {
            this.Tex = texture;
            this.Pos = position;
            this.Rec = new Rectangle(position.ToPoint(), size);
        }
        public void MovePlayer()
        {
            var keyboardState = Keyboard.GetState();
            if (keyboardState.IsKeyDown(Keys.A)) // Left
                Pos -= new Vector2(0,1);

            if(keyboardState.IsKeyDown(Keys.D)) // Right
                Pos += new Vector2(0, 1);

            if (keyboardState.IsKeyDown(Keys.Space)) // Jump

            velocity.Y += 9.82f * 1f / 60f;
            Pos += new Vector2(0, velocity.Y);

            this.Rec = new Rectangle(Pos.ToPoint(), Rec.Size);
        }
        public void Collision()
        {
            velocity.Y = 0;
        }
        public override void Update()
        {
            
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Tex, Pos, Color.White);
        }
    }
}