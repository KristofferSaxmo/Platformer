﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    class BaseClass
    {
        public Texture2D Tex { get; protected set; }
        public Vector2 Pos { get; protected set; }
        public Rectangle Rec { get; protected set; }

        public virtual void Update() { }
        public virtual void Draw(SpriteBatch spriteBatch) { }
    }
}
